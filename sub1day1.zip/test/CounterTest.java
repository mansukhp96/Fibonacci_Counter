import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CounterTest {

  private FibonacciCounter fi;

  @Before
  public void setUp(){
    fi = new Counter();
  }

  @Test
  public void testInit(){
    assertEquals("9",fi.curCount());
  }

}