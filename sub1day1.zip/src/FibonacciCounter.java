public interface FibonacciCounter {
  FibonacciCounter incCount();

  FibonacciCounter decCount();

  int curCount();

  int curCountNum(int fib);
}