public class Counter implements FibonacciCounter {

  public int pos = 1;

  public Counter() {
    //this.pos = pos;
  }

  @Override
  public FibonacciCounter incCount() {
    pos++;
    return this;
  }

  @Override
  public FibonacciCounter decCount() {
    pos--;
    return this;
  }

  @Override
  public int curCount() {
  pos = curCountNum(pos);
    return pos;
  }

  @Override
  public int curCountNum(int pos) {
    if (pos <= 1)
      return pos;
    int i = curCountNum(pos - 1) + curCountNum(pos - 2);
    return i;
  }

//  public static void main(String[] args) {
//    FibonacciCounter fb = new Counter();
//    System.out.println(fb.curCountNum(11));
//    //System.out.println(fb.incCount());
//    //System.out.println(fb.decCount());
//    System.out.println(fb.curCount());
//  }
}